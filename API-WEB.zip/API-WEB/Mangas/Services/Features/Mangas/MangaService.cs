using mangas.Domain.Entities;

namespace mangas.Services.Features.Mangas;

public class MangaService
{
    private List<Manga> _mangas;

    public MangaService()
    {
        _mangas = new List<Manga>();
    }

    public IEnumerable<Manga> GetAll()
    {
        return _mangas;
    }

    public Manga GetById(int id)
    {
        return _mangas.FirstOrDefault(m => m.ID == id);
    }

    public void Add(Manga manga)
    {
        _mangas.Add(manga);
    }

    public void Update(Manga manga)
    {
        var existingManga = GetById(manga.ID);
        if (existingManga != null)
        {
            existingManga.Title = manga.Title;
            existingManga.Author = manga.Author;
            existingManga.PublicationDate = manga.PublicationDate;
        }
    }

    public void Delete(int id)
    {
        var manga = GetById(id);
        if (manga != null)
        {
            _mangas.Remove(manga);
        }
    }
}