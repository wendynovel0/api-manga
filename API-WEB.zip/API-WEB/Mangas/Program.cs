using mangas.Services.Features.Mangas;
using mangas.Infraestructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

// Configurar CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigin",
        builder => builder.WithOrigins("http://localhost:5081") // Cambia a la URL de tu frontend
                          .AllowAnyMethod()
                          .AllowAnyHeader());
});

// Inyección de dependencias
builder.Services.AddSingleton<MangaService>();
builder.Services.AddTransient<MangaRepository>();

// Add services to the container
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configurar el pipeline de la aplicación
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Habilitar CORS antes de cualquier otro middleware que maneje solicitudes
app.UseCors("AllowSpecificOrigin");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
