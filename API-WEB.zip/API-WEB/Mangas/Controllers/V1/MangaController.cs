using mangas.Services.Features.Mangas;
using mangas.Domain.Entities;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace mangas.Controllers.V1;

[ApiController]
[Route("api/[controller]")]
public class MangaController : ControllerBase
{
    private readonly MangaService _mangaService;

    public MangaController(MangaService mangaService)
    {
        _mangaService = mangaService;
    }

    [HttpGet]
    public IEnumerable<Manga> GetAll()
    {
        return _mangaService.GetAll();
    }

    [HttpGet("{id:int}")]
    public ActionResult<Manga> GetById(int id)
    {
        var manga = _mangaService.GetById(id);
        if (manga == null)
        {
            return NotFound();
        }
        return Ok(manga);
    }

    [HttpPost]
    public ActionResult Add(Manga manga)
    {
        _mangaService.Add(manga);
        return CreatedAtAction(nameof(GetById), new { id = manga.ID }, manga);
    }


    [HttpPut]
    public IActionResult Update (int id, Manga manga)
    {
        if (id != manga.ID)
        {
            return BadRequest();
        }

        _mangaService.Update(manga);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        _mangaService.Delete(id);
        return NoContent();
    }

}
